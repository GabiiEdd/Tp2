# tailwind-carrito-manual
 
